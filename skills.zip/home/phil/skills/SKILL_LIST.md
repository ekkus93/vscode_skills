# Skill List

This file lists reusable skills available in the shared workspace skill library.

## How to use this index
1. Match the user task to the closest skill.
2. Open that skill directory.
3. Read the skill's `SKILL.md`.
4. Follow the skill's procedure, constraints, and output format.
5. Do not claim to have used a skill unless you actually read its `SKILL.md`.

## Skills

### yahoo-finance-cli
- Path: `skills/yahoo-finance-cli/`
- Use for: fetching stock prices, financial data, and market summaries using Yahoo Finance CLI
- Typical outputs: stock quotes, financial metrics, market overviews

### current-date-time
- Path: `skills/current-date-time/`
- Use for: getting the current local date, current time, or current datetime from the system clock
- Typical outputs: current local time, current date, UTC timestamp

### weather
- Path: `skills/weather/`
- Use for: getting the current weather, temperature, and simple forecast for a city or location
- Typical outputs: current conditions, temperature summary, short forecast

### wikipedia
- Path: `skills/wikipedia/`
- Use for: searching Wikipedia and getting a concise summary for a topic, person, place, event, or concept
- Typical outputs: page summary, resolved topic title, short encyclopedia overview

### docx-to-markdown
- Path: `skills/docx-to-markdown/`
- Use for: converting `.docx` and legacy `.doc` files into Markdown `.md` files
- Typical outputs: converted markdown file, output path confirmation